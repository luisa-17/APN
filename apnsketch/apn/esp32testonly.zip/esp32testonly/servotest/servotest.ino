/*
 * ========================================
 * SERVO MOTOR TEST - 4 Servos
 * ========================================
 * ⚠️ IMPORTANT: Use external 5V 2A+ power for servos!
 *    ESP32 cannot provide enough current for 4 servos.
 * 
 * Wiring per servo:
 *   Red    → 5V (EXTERNAL power supply)
 *   Brown  → GND (common with ESP32)
 *   Orange → Signal GPIO
 * 
 * Pins:
 *   Servo 1 (Gyro 1):    GPIO 16
 *   Servo 2 (Gyro 2):    GPIO 17
 *   Servo 3 (Breaker 1): GPIO 18
 *   Servo 4 (Breaker 2): GPIO 23
 * 
 * Library: ESP32Servo by Kevin Harrington
 * ========================================
 */

#include <ESP32Servo.h>

#define SERVO_GYRO_1     16
#define SERVO_GYRO_2     17
#define BREAKER_SERVO_1  18
#define BREAKER_SERVO_2  23

// Create servo objects
Servo servo1;
Servo servo2;
Servo servo3;
Servo servo4;

// Position tracking
int pos1 = 90, pos2 = 90, pos3 = 90, pos4 = 90;
int selectedServo = 1;

// Breaker positions
const int BREAKER_ON = 90;
const int BREAKER_OFF = 0;

void setup() {
  Serial.begin(115200);
  delay(1000);
  
  // Allocate PWM timers for servos
  ESP32PWM::allocateTimer(0);
  ESP32PWM::allocateTimer(1);
  ESP32PWM::allocateTimer(2);
  ESP32PWM::allocateTimer(3);
  
  // Attach servos with pulse width range
  servo1.attach(SERVO_GYRO_1, 500, 2400);
  servo2.attach(SERVO_GYRO_2, 500, 2400);
  servo3.attach(BREAKER_SERVO_1, 500, 2400);
  servo4.attach(BREAKER_SERVO_2, 500, 2400);
  
  // Initialize all servos to center
  servo1.write(90);
  servo2.write(90);
  servo3.write(90);
  servo4.write(90);
  
  Serial.println("╔════════════════════════════════════════╗");
  Serial.println("║      SERVO MOTOR TEST - 4 Servos       ║");
  Serial.println("╠════════════════════════════════════════╣");
  Serial.println("║ Pins:                                  ║");
  Serial.println("║   Servo 1 (Gyro 1):    GPIO 16         ║");
  Serial.println("║   Servo 2 (Gyro 2):    GPIO 17         ║");
  Serial.println("║   Servo 3 (Breaker 1): GPIO 18         ║");
  Serial.println("║   Servo 4 (Breaker 2): GPIO 23         ║");
  Serial.println("╠════════════════════════════════════════╣");
  Serial.println("║ Commands:                              ║");
  Serial.println("║   1-4      Select servo                ║");
  Serial.println("║   0-180    Set angle                   ║");
  Serial.println("║   c        Center all (90°)            ║");
  Serial.println("║   a        Test all servos             ║");
  Serial.println("║   s        Sweep selected servo        ║");
  Serial.println("║   t        Trip breakers (emergency)   ║");
  Serial.println("║   r        Reset breakers              ║");
  Serial.println("╚════════════════════════════════════════╝");
  Serial.println();
  
  // Run initial test
  Serial.println("Running initial test...");
  testAllServos();
}

void testAllServos() {
  Serial.println("Testing all servos...");
  
  Serial.println("  All → 45°");
  servo1.write(45); servo2.write(45); servo3.write(45); servo4.write(45);
  delay(500);
  
  Serial.println("  All → 135°");
  servo1.write(135); servo2.write(135); servo3.write(135); servo4.write(135);
  delay(500);
  
  Serial.println("  All → 90° (center)");
  servo1.write(90); servo2.write(90); servo3.write(90); servo4.write(90);
  pos1 = pos2 = pos3 = pos4 = 90;
  
  Serial.println("✅ Test complete!");
  Serial.println();
}

void sweepServo(int num) {
  Serial.print("Sweeping Servo "); Serial.println(num);
  
  Servo* servo;
  int* pos;
  
  switch(num) {
    case 1: servo = &servo1; pos = &pos1; break;
    case 2: servo = &servo2; pos = &pos2; break;
    case 3: servo = &servo3; pos = &pos3; break;
    case 4: servo = &servo4; pos = &pos4; break;
    default: return;
  }
  
  // Sweep 0 to 180
  for (int i = 0; i <= 180; i += 3) {
    servo->write(i);
    delay(15);
  }
  
  // Sweep 180 to 0
  for (int i = 180; i >= 0; i -= 3) {
    servo->write(i);
    delay(15);
  }
  
  // Return to center
  servo->write(90);
  *pos = 90;
  
  Serial.println("Sweep complete!");
}

void tripBreakers() {
  Serial.println("⚠️ TRIPPING BREAKERS - Emergency OFF!");
  
  for (int i = BREAKER_ON; i >= BREAKER_OFF; i -= 5) {
    servo3.write(i);
    servo4.write(i);
    delay(20);
  }
  
  pos3 = pos4 = BREAKER_OFF;
  Serial.println("🔴 BREAKERS TRIPPED - Power Disconnected");
  Serial.println();
}

void resetBreakers() {
  Serial.println("Resetting breakers...");
  
  for (int i = BREAKER_OFF; i <= BREAKER_ON; i += 3) {
    servo3.write(i);
    servo4.write(i);
    delay(30);
  }
  
  pos3 = pos4 = BREAKER_ON;
  Serial.println("✅ BREAKERS RESET - Power Connected");
  Serial.println();
}

void printStatus() {
  Serial.println("┌─────────────────────────────────────┐");
  Serial.println("│         SERVO POSITIONS             │");
  Serial.println("├─────────────────────────────────────┤");
  Serial.print("│ S1: "); Serial.print(pos1); Serial.print("°");
  Serial.print("  S2: "); Serial.print(pos2); Serial.print("°");
  Serial.print("  S3: "); Serial.print(pos3); Serial.print("°");
  Serial.print("  S4: "); Serial.print(pos4); Serial.println("°  │");
  Serial.print("│ Selected: Servo "); Serial.print(selectedServo);
  Serial.println("                   │");
  Serial.print("│ Breakers: ");
  Serial.println((pos3 == BREAKER_ON && pos4 == BREAKER_ON) ? "✅ ON          │" : "🔴 OFF         │");
  Serial.println("└─────────────────────────────────────┘");
  Serial.println();
}

void loop() {
  if (Serial.available()) {
    String input = Serial.readStringUntil('\n');
    input.trim();
    
    if (input == "c") {
      Serial.println("Centering all servos...");
      servo1.write(90); servo2.write(90); servo3.write(90); servo4.write(90);
      pos1 = pos2 = pos3 = pos4 = 90;
    }
    else if (input == "a") {
      testAllServos();
    }
    else if (input == "s") {
      sweepServo(selectedServo);
    }
    else if (input == "t") {
      tripBreakers();
    }
    else if (input == "r") {
      resetBreakers();
    }
    else if (input.length() == 1 && input.toInt() >= 1 && input.toInt() <= 4) {
      selectedServo = input.toInt();
      Serial.print("Selected: Servo "); Serial.println(selectedServo);
    }
    else {
      int angle = input.toInt();
      if (angle >= 0 && angle <= 180) {
        Serial.print("Moving Servo "); Serial.print(selectedServo);
        Serial.print(" to "); Serial.print(angle); Serial.println("°");
        
        switch(selectedServo) {
          case 1: servo1.write(angle); pos1 = angle; break;
          case 2: servo2.write(angle); pos2 = angle; break;
          case 3: servo3.write(angle); pos3 = angle; break;
          case 4: servo4.write(angle); pos4 = angle; break;
        }
      }
    }
    
    printStatus();
  }
  
  delay(10);
}
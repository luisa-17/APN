/*
 * ========================================
 * VOLTAGE SENSOR TEST - 2 Channels
 * ========================================
 * For 12V solar battery monitoring
 * 
 * Voltage Divider Wiring:
 *   12V+ → 27kΩ → Junction → 10kΩ → GND
 *   Junction → GPIO
 * 
 * Pins (ADC1 - WiFi Safe):
 *   Channel 1 → GPIO 32
 *   Channel 2 → GPIO 33
 * ========================================
 */

#define VOLTAGE_SENSOR_1  32
#define VOLTAGE_SENSOR_2  33

// Voltage divider resistor values
const float R1 = 27000.0;  // Resistor to Vin (ohms)
const float R2 = 10000.0;  // Resistor to GND (ohms)

// ESP32 ADC settings
const float ADC_REF = 3.3;
const int ADC_RES = 4095;

// Calibration factors (adjust with multimeter)
float cal1 = 1.0;
float cal2 = 1.0;

void setup() {
  Serial.begin(115200);
  delay(1000);
  
  analogReadResolution(12);
  analogSetPinAttenuation(VOLTAGE_SENSOR_1, ADC_11db);
  analogSetPinAttenuation(VOLTAGE_SENSOR_2, ADC_11db);
  
  Serial.println("╔════════════════════════════════════════╗");
  Serial.println("║    VOLTAGE SENSOR TEST - 2 Channels    ║");
  Serial.println("╠════════════════════════════════════════╣");
  Serial.println("║ Pins (ADC1 - WiFi Safe):               ║");
  Serial.println("║   Channel 1: GPIO 32                   ║");
  Serial.println("║   Channel 2: GPIO 33                   ║");
  Serial.println("╠════════════════════════════════════════╣");
  Serial.println("║ Voltage Divider: 27kΩ + 10kΩ           ║");
  Serial.println("║ Max Input: ~12.2V                      ║");
  Serial.println("╚════════════════════════════════════════╝");
  Serial.println();
}

float readVoltage(int pin, float calibration) {
  long sum = 0;
  for (int i = 0; i < 20; i++) {
    sum += analogRead(pin);
    delayMicroseconds(500);
  }
  float avg = sum / 20.0;
  
  // Convert ADC to voltage at pin
  float adcVoltage = (avg * ADC_REF) / ADC_RES;
  
  // Calculate input voltage: Vin = Vout × (R1 + R2) / R2
  float inputVoltage = adcVoltage * ((R1 + R2) / R2) * calibration;
  
  return inputVoltage;
}

void printVoltageStatus(float v) {
  Serial.print("│   Status: ");
  if (v < 0.5) Serial.println("❌ Disconnected        │");
  else if (v < 10.5) Serial.println("🔴 LOW - Charge!       │");
  else if (v < 11.5) Serial.println("🟡 Moderate            │");
  else if (v < 14.0) Serial.println("✅ Normal              │");
  else if (v < 14.8) Serial.println("🔵 Charging            │");
  else Serial.println("⚠️  Overvoltage!        │");
}

void printBar(float value, float maxVal) {
  int bars = map(constrain(value * 10, 0, maxVal * 10), 0, maxVal * 10, 0, 15);
  Serial.print("[");
  for (int i = 0; i < 15; i++) {
    Serial.print(i < bars ? "█" : "░");
  }
  Serial.print("] ");
  Serial.print(value, 1);
  Serial.print("V");
}

void loop() {
  int raw1 = analogRead(VOLTAGE_SENSOR_1);
  int raw2 = analogRead(VOLTAGE_SENSOR_2);
  
  float v1 = readVoltage(VOLTAGE_SENSOR_1, cal1);
  float v2 = readVoltage(VOLTAGE_SENSOR_2, cal2);
  
  Serial.println("┌────────────────────────────────────┐");
  Serial.println("│      VOLTAGE SENSOR READINGS       │");
  Serial.println("├────────────────────────────────────┤");
  
  // Channel 1
  Serial.println("│ --- Channel 1 (GPIO 32) ---        │");
  Serial.print("│   Raw ADC: "); Serial.println(raw1);
  Serial.print("│   Voltage: "); Serial.print(v1, 2); Serial.println(" V");
  printVoltageStatus(v1);
  
  // Channel 2
  Serial.println("│ --- Channel 2 (GPIO 33) ---        │");
  Serial.print("│   Raw ADC: "); Serial.println(raw2);
  Serial.print("│   Voltage: "); Serial.print(v2, 2); Serial.println(" V");
  printVoltageStatus(v2);
  
  Serial.println("├────────────────────────────────────┤");
  
  // Bar graphs
  Serial.print("│ V1: "); printBar(v1, 15.0); Serial.println("      │");
  Serial.print("│ V2: "); printBar(v2, 15.0); Serial.println("      │");
  
  Serial.println("└────────────────────────────────────┘");
  Serial.println();
  
  delay(1000);
}
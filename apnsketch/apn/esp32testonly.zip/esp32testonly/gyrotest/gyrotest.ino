/*
 * ========================================
 * MPU6050 GYROSCOPE/ACCELEROMETER TEST
 * ========================================
 * Wiring:
 *   VCC → 3.3V (or 5V if module has regulator)
 *   GND → GND
 *   SDA → GPIO 21
 *   SCL → GPIO 22
 *   AD0 → GND (for address 0x68)
 * 
 * Used for earthquake/vibration detection
 * ========================================
 */

#include <Wire.h>

#define MPU_SDA  21
#define MPU_SCL  22
#define MPU_ADDR 0x68

// Raw sensor data
int16_t ax, ay, az;
int16_t gx, gy, gz;
int16_t rawTemp;

// Calibration offsets
float axOff = 0, ayOff = 0, azOff = 0;
float gxOff = 0, gyOff = 0, gzOff = 0;

// Detection thresholds
const float SHAKE_THRESHOLD = 0.3;      // g deviation
const float EARTHQUAKE_THRESHOLD = 0.8; // Strong shake
const float GYRO_THRESHOLD = 50.0;      // °/s rotation

void setup() {
  Serial.begin(115200);
  delay(1000);
  
  Wire.begin(MPU_SDA, MPU_SCL);
  Wire.setClock(400000);
  
  Serial.println("╔════════════════════════════════════════╗");
  Serial.println("║     MPU6050 SENSOR TEST                ║");
  Serial.println("╠════════════════════════════════════════╣");
  Serial.println("║ Pins:                                  ║");
  Serial.println("║   SDA: GPIO 21                         ║");
  Serial.println("║   SCL: GPIO 22                         ║");
  Serial.println("║ Address: 0x68                          ║");
  Serial.println("╚════════════════════════════════════════╝");
  Serial.println();
  
  // Check connection
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x75);  // WHO_AM_I register
  Wire.endTransmission(false);
  Wire.requestFrom(MPU_ADDR, 1);
  
  if (Wire.available()) {
    uint8_t deviceId = Wire.read();
    Serial.print("Device ID: 0x");
    Serial.println(deviceId, HEX);
    
    if (deviceId == 0x68 || deviceId == 0x98) {
      Serial.println("✅ MPU6050 Connected!");
    } else {
      Serial.println("⚠️ Unknown device ID");
    }
  } else {
    Serial.println("❌ MPU6050 NOT FOUND!");
    Serial.println("Check wiring!");
    while(1) delay(1000);
  }
  
  // Initialize MPU6050 - Wake up
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x6B);  // PWR_MGMT_1
  Wire.write(0x00);  // Wake up
  Wire.endTransmission();
  delay(100);
  
  // Set accelerometer range to ±2g
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x1C);
  Wire.write(0x00);
  Wire.endTransmission();
  
  // Set gyroscope range to ±250°/s
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x1B);
  Wire.write(0x00);
  Wire.endTransmission();
  
  Serial.println();
  Serial.println("Calibrating... Keep sensor STILL!");
  delay(2000);
  calibrate();
  Serial.println("✅ Calibration complete!");
  Serial.println();
}

void calibrate() {
  long axSum = 0, aySum = 0, azSum = 0;
  long gxSum = 0, gySum = 0, gzSum = 0;
  
  for (int i = 0; i < 100; i++) {
    readMPU();
    axSum += ax;
    aySum += ay;
    azSum += az;
    gxSum += gx;
    gySum += gy;
    gzSum += gz;
    delay(10);
    if (i % 20 == 0) Serial.print(".");
  }
  Serial.println();
  
  // Calculate offsets
  axOff = axSum / 100.0 / 16384.0;
  ayOff = aySum / 100.0 / 16384.0;
  azOff = (azSum / 100.0 / 16384.0) - 1.0;  // Subtract 1g from Z-axis
  gxOff = gxSum / 100.0 / 131.0;
  gyOff = gySum / 100.0 / 131.0;
  gzOff = gzSum / 100.0 / 131.0;
}

void readMPU() {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x3B);  // ACCEL_XOUT_H
  Wire.endTransmission(false);
  Wire.requestFrom(MPU_ADDR, 14);
  
  ax = Wire.read() << 8 | Wire.read();
  ay = Wire.read() << 8 | Wire.read();
  az = Wire.read() << 8 | Wire.read();
  rawTemp = Wire.read() << 8 | Wire.read();
  gx = Wire.read() << 8 | Wire.read();
  gy = Wire.read() << 8 | Wire.read();
  gz = Wire.read() << 8 | Wire.read();
}

void loop() {
  readMPU();
  
  // Convert to physical units with calibration
  float axG = (ax / 16384.0) - axOff;
  float ayG = (ay / 16384.0) - ayOff;
  float azG = (az / 16384.0) - azOff;
  
  float gxDeg = (gx / 131.0) - gxOff;
  float gyDeg = (gy / 131.0) - gyOff;
  float gzDeg = (gz / 131.0) - gzOff;
  
  // Temperature
  float tempC = rawTemp / 340.0 + 36.53;
  
  // Calculate total acceleration and deviation
  float totalAccel = sqrt(axG*axG + ayG*ayG + azG*azG);
  float deviation = abs(totalAccel - 1.0);
  
  // Calculate tilt angles
  float pitch = atan2(axG, sqrt(ayG*ayG + azG*azG)) * 180.0 / PI;
  float roll = atan2(ayG, sqrt(axG*axG + azG*azG)) * 180.0 / PI;
  
  // Motion detection
  bool shaking = (deviation > SHAKE_THRESHOLD) || 
                 (abs(gxDeg) > GYRO_THRESHOLD) ||
                 (abs(gyDeg) > GYRO_THRESHOLD) ||
                 (abs(gzDeg) > GYRO_THRESHOLD);
  
  bool earthquake = deviation > EARTHQUAKE_THRESHOLD;
  
  // Display results
  Serial.println("┌────────────────────────────────────┐");
  Serial.println("│        MPU6050 READINGS            │");
  Serial.println("├────────────────────────────────────┤");
  
  Serial.print("│ Accel (g): X=");
  Serial.print(axG, 2);
  Serial.print(" Y=");
  Serial.print(ayG, 2);
  Serial.print(" Z=");
  Serial.println(azG, 2);
  
  Serial.print("│ Gyro(°/s): X=");
  Serial.print(gxDeg, 1);
  Serial.print(" Y=");
  Serial.print(gyDeg, 1);
  Serial.print(" Z=");
  Serial.println(gzDeg, 1);
  
  Serial.print("│ Total Accel: ");
  Serial.print(totalAccel, 3);
  Serial.println(" g");
  
  Serial.print("│ Pitch: ");
  Serial.print(pitch, 1);
  Serial.print("°  Roll: ");
  Serial.print(roll, 1);
  Serial.println("°");
  
  Serial.print("│ Temp: ");
  Serial.print(tempC, 1);
  Serial.println("°C");
  
  Serial.println("├────────────────────────────────────┤");
  Serial.println("│ --- MOTION DETECTION ---           │");
  
  Serial.print("│ Deviation: ");
  Serial.print(deviation, 3);
  Serial.println(" g");
  
  Serial.print("│ Status: ");
  if (earthquake) {
    Serial.println("🔴 EARTHQUAKE DETECTED!  │");
  } else if (shaking) {
    Serial.println("🟡 Movement/Vibration    │");
  } else {
    Serial.println("✅ Stable                │");
  }
  
  // Stability bar
  Serial.print("│ Stability: [");
  int stabilityBars = 15 - map(constrain(deviation * 1000, 0, 500), 0, 500, 0, 15);
  for (int i = 0; i < 15; i++) {
    if (i < stabilityBars) Serial.print("█");
    else Serial.print("░");
  }
  Serial.println("]     │");
  
  Serial.println("└────────────────────────────────────┘");
  
  // Earthquake alert
  if (earthquake) {
    Serial.println();
    Serial.println("🚨🚨🚨 EARTHQUAKE/STRONG VIBRATION 🚨🚨🚨");
    Serial.println("      TRIGGERING SAFETY MEASURES!");
  }
  
  Serial.println();
  
  delay(200);
}
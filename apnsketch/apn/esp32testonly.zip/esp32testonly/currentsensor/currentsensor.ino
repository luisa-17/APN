/*
 * ========================================
 * CURRENT SENSOR TEST - 2x ACS712
 * ========================================
 * Using ACS712 Library by Rob Tillaart
 * 
 * Install: Sketch → Include Library → Manage Libraries
 *          Search "ACS712" by Rob Tillaart → Install
 * 
 * Wiring:
 *   VCC → 5V
 *   GND → GND
 *   OUT → GPIO
 * 
 * Pins (ADC1 - WiFi Safe):
 *   Channel 1 → GPIO 34 (input only)
 *   Channel 2 → GPIO 35 (input only)
 * 
 * ACS712 Models:
 *   ACS712_05B → ±5A
 *   ACS712_20A → ±20A
 *   ACS712_30A → ±30A
 * ========================================
 */

#include "ACS712.h"

#define CURRENT_SENSOR_1  34
#define CURRENT_SENSOR_2  35

// Create ACS712 objects
// Parameters: (pin, voltage reference, ADC max value, mV per Amp)
// For ACS712-05B: 185 mV/A
// For ACS712-20A: 100 mV/A
// For ACS712-30A: 66 mV/A

// Change ACS712_05B to your model (ACS712_20A or ACS712_30A)
ACS712 sensor1(CURRENT_SENSOR_1, 3.3, 4095, 185);  // 5A model
ACS712 sensor2(CURRENT_SENSOR_2, 3.3, 4095, 185);  // 5A model

// System voltage for power calculation
const float SYSTEM_VOLTAGE = 12.0;

// Overcurrent threshold
const float OVERCURRENT_LIMIT = 4.0;  // Amps

void setup() {
  Serial.begin(115200);
  delay(1000);
  
  Serial.println("╔════════════════════════════════════════╗");
  Serial.println("║   CURRENT SENSOR TEST - ACS712         ║");
  Serial.println("║   Using ACS712 Library                 ║");
  Serial.println("╠════════════════════════════════════════╣");
  Serial.println("║ Pins (ADC1 - WiFi Safe):               ║");
  Serial.println("║   Channel 1: GPIO 34                   ║");
  Serial.println("║   Channel 2: GPIO 35                   ║");
  Serial.println("╚════════════════════════════════════════╝");
  Serial.println();
  
  // Calibration - DISCONNECT ALL LOADS FIRST!
  Serial.println("╔════════════════════════════════════════╗");
  Serial.println("║         AUTO-CALIBRATION               ║");
  Serial.println("║   Disconnect all loads from sensors!   ║");
  Serial.println("║   Starting in 3 seconds...             ║");
  Serial.println("╚════════════════════════════════════════╝");
  
  delay(3000);
  
  Serial.println("Calibrating Sensor 1...");
  sensor1.autoMidPoint();
  Serial.print("  MidPoint: ");
  Serial.println(sensor1.getMidPoint());
  
  Serial.println("Calibrating Sensor 2...");
  sensor2.autoMidPoint();
  Serial.print("  MidPoint: ");
  Serial.println(sensor2.getMidPoint());
  
  Serial.println();
  Serial.println("✅ Calibration Complete!");
  Serial.println("   You can now connect loads.");
  Serial.println();
  delay(2000);
}

void loop() {
  // Read current from both sensors
  float current1 = sensor1.mA_DC() / 1000.0;  // Convert mA to A
  float current2 = sensor2.mA_DC() / 1000.0;
  
  // Calculate power
  float power1 = abs(current1) * SYSTEM_VOLTAGE;
  float power2 = abs(current2) * SYSTEM_VOLTAGE;
  float totalPower = power1 + power2;
  float totalCurrent = abs(current1) + abs(current2);
  
  // Print results
  Serial.println("┌────────────────────────────────────┐");
  Serial.println("│     CURRENT SENSOR READINGS        │");
  Serial.println("├────────────────────────────────────┤");
  
  // Channel 1
  Serial.println("│ --- Channel 1 (GPIO 34) ---        │");
  Serial.print("│   Current: ");
  Serial.print(current1, 3);
  Serial.println(" A");
  Serial.print("│   Power:   ");
  Serial.print(power1, 2);
  Serial.println(" W");
  Serial.print("│   Status:  ");
  printCurrentStatus(current1);
  
  // Channel 2
  Serial.println("│ --- Channel 2 (GPIO 35) ---        │");
  Serial.print("│   Current: ");
  Serial.print(current2, 3);
  Serial.println(" A");
  Serial.print("│   Power:   ");
  Serial.print(power2, 2);
  Serial.println(" W");
  Serial.print("│   Status:  ");
  printCurrentStatus(current2);
  
  Serial.println("├────────────────────────────────────┤");
  
  // Totals
  Serial.println("│ --- TOTALS ---                     │");
  Serial.print("│   Total Current: ");
  Serial.print(totalCurrent, 3);
  Serial.println(" A");
  Serial.print("│   Total Power:   ");
  Serial.print(totalPower, 2);
  Serial.println(" W");
  
  Serial.println("├────────────────────────────────────┤");
  
  // Visual bars
  Serial.print("│ I1: ");
  printCurrentBar(current1);
  Serial.print("│ I2: ");
  printCurrentBar(current2);
  
  Serial.println("└────────────────────────────────────┘");
  
  // Overcurrent alert
  if (abs(current1) > OVERCURRENT_LIMIT || abs(current2) > OVERCURRENT_LIMIT) {
    Serial.println();
    Serial.println("🚨🚨🚨 OVERCURRENT ALERT! 🚨🚨🚨");
  }
  
  Serial.println();
  
  delay(500);
}

void printCurrentStatus(float current) {
  float absCurrent = abs(current);
  
  if (absCurrent < 0.05) {
    Serial.println("⚪ No load");
  } else if (absCurrent < 1.0) {
    Serial.println("🟢 Low");
  } else if (absCurrent < 2.5) {
    Serial.println("🟡 Moderate");
  } else if (absCurrent < OVERCURRENT_LIMIT) {
    Serial.println("🟠 High");
  } else {
    Serial.println("🔴 OVERCURRENT!");
  }
}

void printCurrentBar(float current) {
  float absCurrent = abs(current);
  int bars = map(constrain(absCurrent * 100, 0, 500), 0, 500, 0, 15);
  
  // Direction indicator
  Serial.print(current >= 0 ? "+" : "-");
  
  Serial.print("[");
  for (int i = 0; i < 15; i++) {
    if (i < bars) {
      Serial.print("█");
    } else {
      Serial.print("░");
    }
  }
  Serial.print("] ");
  Serial.print(absCurrent, 2);
  Serial.println(" A           │");
}
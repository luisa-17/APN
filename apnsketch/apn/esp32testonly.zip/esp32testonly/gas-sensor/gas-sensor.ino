/*
 * ========================================
 * GAS SENSOR TEST - MQ-2/MQ-5/MQ-135
 * ========================================
 * Wiring:
 *   VCC → 5V (heater needs 5V)
 *   GND → GND
 *   AO  → GPIO 25
 * 
 * ⚠️ Warmup: 2-3 minutes required for accurate readings
 * ⚠️ Heater gets HOT - handle with care
 * 
 * Pin: GPIO 25
 * Note: ADC2 pin - read before WiFi initialization
 * ========================================
 */

#define GAS_SENSOR  25

// Threshold levels (adjust based on your environment and sensor)
const int THRESHOLD_CLEAN = 500;
const int THRESHOLD_LOW = 1000;
const int THRESHOLD_MODERATE = 2000;
const int THRESHOLD_HIGH = 3000;
const int THRESHOLD_DANGER = 3500;

// Timing
unsigned long startTime;
bool warmedUp = false;
int baseline = 0;

void setup() {
  Serial.begin(115200);
  delay(1000);
  
  startTime = millis();
  
  analogReadResolution(12);
  analogSetPinAttenuation(GAS_SENSOR, ADC_11db);
  
  Serial.println("╔════════════════════════════════════════╗");
  Serial.println("║      GAS SENSOR TEST - MQ Series       ║");
  Serial.println("╠════════════════════════════════════════╣");
  Serial.println("║ Pin: GPIO 25                           ║");
  Serial.println("╠════════════════════════════════════════╣");
  Serial.println("║ ⚠️  WARMUP REQUIRED: 2-3 minutes       ║");
  Serial.println("║    Readings will stabilize over time   ║");
  Serial.println("╠════════════════════════════════════════╣");
  Serial.println("║ Gas Types (depends on model):          ║");
  Serial.println("║   MQ-2:  LPG, Propane, Smoke           ║");
  Serial.println("║   MQ-5:  Natural Gas, LPG              ║");
  Serial.println("║   MQ-135: CO2, NH3, Air Quality        ║");
  Serial.println("╚════════════════════════════════════════╝");
  Serial.println();
}

void printGasStatus(int value) {
  Serial.print("│ Status: ");
  if (value < THRESHOLD_CLEAN) {
    Serial.println("✅ CLEAN - Air quality good  │");
  } else if (value < THRESHOLD_LOW) {
    Serial.println("🟢 LOW - Minimal gas         │");
  } else if (value < THRESHOLD_MODERATE) {
    Serial.println("🟡 MODERATE - Check area     │");
  } else if (value < THRESHOLD_HIGH) {
    Serial.println("🟠 HIGH - Ventilate!         │");
  } else if (value < THRESHOLD_DANGER) {
    Serial.println("🔴 VERY HIGH - Take action!  │");
  } else {
    Serial.println("⛔ DANGER - Evacuate!        │");
  }
}

void printGasBar(int value) {
  int bars = map(constrain(value, 0, 4095), 0, 4095, 0, 20);
  Serial.print("[");
  for (int i = 0; i < 20; i++) {
    if (i < bars) Serial.print("█");
    else Serial.print("░");
  }
  Serial.println("]       │");
}

void loop() {
  // Read multiple samples and average
  long sum = 0;
  for (int i = 0; i < 20; i++) {
    sum += analogRead(GAS_SENSOR);
    delay(5);
  }
  int gasValue = sum / 20;
  
  // Calculate voltage
  float voltage = gasValue * (3.3 / 4095.0);
  
  // Warmup timer
  unsigned long elapsedSec = (millis() - startTime) / 1000;
  int warmupRemaining = 180 - elapsedSec;  // 3 minutes
  
  // Set baseline after warmup
  if (warmupRemaining <= 0 && !warmedUp) {
    warmedUp = true;
    baseline = gasValue;
    Serial.println("✅ Warmup complete! Baseline captured.");
    Serial.println();
  }
  
  // Display results
  Serial.println("┌────────────────────────────────────┐");
  Serial.println("│        GAS SENSOR READING          │");
  Serial.println("├────────────────────────────────────┤");
  
  Serial.print("│ Raw Value: "); Serial.println(gasValue);
  Serial.print("│ Voltage:   "); Serial.print(voltage, 3); Serial.println(" V");
  
  if (warmedUp) {
    Serial.print("│ Baseline:  "); Serial.println(baseline);
    int deviation = gasValue - baseline;
    Serial.print("│ Deviation: ");
    if (deviation >= 0) Serial.print("+");
    Serial.println(deviation);
  }
  
  Serial.println("├────────────────────────────────────┤");
  printGasStatus(gasValue);
  
  // Warmup progress
  if (!warmedUp) {
    Serial.println("├────────────────────────────────────┤");
    Serial.print("│ ⏱️  Warmup: ");
    Serial.print(warmupRemaining);
    Serial.println(" seconds remaining  │");
    
    // Progress bar
    int progress = map(elapsedSec, 0, 180, 0, 20);
    Serial.print("│ [");
    for (int i = 0; i < 20; i++) {
      if (i < progress) Serial.print("█");
      else Serial.print("░");
    }
    Serial.println("]           │");
  }
  
  Serial.println("├────────────────────────────────────┤");
  Serial.print("│ Level: ");
  printGasBar(gasValue);
  
  Serial.println("└────────────────────────────────────┘");
  
  // Gas alert
  if (warmedUp && gasValue > THRESHOLD_HIGH) {
    Serial.println();
    Serial.println("🚨🚨🚨 GAS ALERT! 🚨🚨🚨");
    Serial.println("Ventilate area immediately!");
  }
  
  Serial.println();
  
  delay(1000);
}